import { SLRProtocol, SLRRecord, StudyCharacteristic } from "../types/slr";

export const MAX_INTRO_RECORDS = 100;
export const MAX_TITLE_RECORDS = 50;
export const MAX_CONTENT_RECORDS = 50;

const STOP_WORDS = new Set([
  "the","and","for","with","from","that","this","into","using","based","study","studies","review","systematic","literature","analysis","approach","methods","method","results","effect","effects","evidence","research","data","model","models","of","in","on","to","a","an","by","or","as","at","is","are","be","was","were","their","these","those","how","what","which","where","when","than","through"
]);

const normalize = (value: unknown) =>
  typeof value === "string" ? value.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim() : "";

const tokens = (value: unknown) =>
  Array.from(new Set(normalize(value).split(/\s+/).filter((t) => t.length >= 4 && !STOP_WORDS.has(t))));

const buildScopeTerms = (protocol: SLRProtocol) => {
  const values = [
    protocol.title,
    ...(protocol.primaryResearchQuestions || []),
    ...(protocol.secondaryObjectives || []),
    protocol.objectivesPICO?.population,
    protocol.objectivesPICO?.intervention,
    protocol.objectivesPICO?.outcomes,
    protocol.objectivesPICOC?.population,
    protocol.objectivesPICOC?.intervention,
    protocol.objectivesPICOC?.outcomes,
    protocol.objectivesPICOC?.context,
    protocol.objectivesPEO?.population,
    protocol.objectivesPEO?.exposure,
    protocol.objectivesPEO?.outcomes,
    protocol.objectivesPEO?.setting,
  ];
  return tokens(values.filter(Boolean).join(" "));
};

const overlapScore = (queryTerms: string[], value: unknown) => {
  const valueTerms = new Set(tokens(value));
  if (!queryTerms.length || !valueTerms.size) return 0;
  return queryTerms.reduce((score, term) => score + (valueTerms.has(term) ? 1 : 0), 0);
};

const characteristicMap = (characteristics: StudyCharacteristic[]) =>
  new Map(characteristics.map((c) => [c.recordId, c]));

/**
 * First-stage selection: rank only by bibliographic title relevance to the
 * review scope. This deliberately does not use abstracts or extracted data.
 */
export const selectIntroductionRecords = (records: SLRRecord[], protocol: SLRProtocol) => {
  if (records.length <= MAX_INTRO_RECORDS) return records;
  const scopeTerms = buildScopeTerms(protocol);
  return records
    .map((record, index) => ({
      record,
      index,
      score: overlapScore(scopeTerms, record.title) * 10 + (normalize(record.title).length ? 1 : 0),
    }))
    .sort((a, b) => b.score - a.score || a.index - b.index)
    .slice(0, MAX_INTRO_RECORDS)
    .map((item) => item.record);
};

/**
 * Second-stage selection: from the title-relevant set, prioritize records
 * whose supplied title/abstract/metadata explicitly describe methods, study
 * design, content/topic, intervention/focus, outcomes or context. No AI call
 * is made for selection.
 */
export const selectContentRecords = (
  records: SLRRecord[],
  protocol: SLRProtocol,
  characteristics: StudyCharacteristic[] = []
) => {
  if (records.length <= MAX_CONTENT_RECORDS) return records;
  const scopeTerms = buildScopeTerms(protocol);
  const cmap = characteristicMap(characteristics);
  const methodTerms = tokens(`${protocol.objectivesPICO?.studyDesigns || ""} ${protocol.objectivesPICOC?.studyDesigns || ""} ${protocol.objectivesPEO?.studyDesigns || ""} method methodology intervention technology exposure algorithm experiment simulation model case study survey cohort qualitative quantitative`);

  return records
    .map((record, index) => {
      const c = cmap.get(record.id);
      const methodContent = [
        record.abstract,
        record.studyType,
        c?.studyDesign,
        c?.interventionOrFocus,
        c?.category,
        c?.population,
        c?.primaryOutcome,
        c?.keyFinding,
      ].join(" ");
      const score =
        overlapScore(scopeTerms, record.title) * 5 +
        overlapScore(scopeTerms, methodContent) * 3 +
        overlapScore(methodTerms, methodContent) * 2 +
        (normalize(record.abstract).length ? 2 : 0) +
        (c ? 4 : 0);
      return { record, index, score };
    })
    .sort((a, b) => b.score - a.score || a.index - b.index)
    .slice(0, MAX_CONTENT_RECORDS)
    .map((item) => item.record);
};

export const selectTitleRecords = (
  records: SLRRecord[],
  protocol: SLRProtocol,
  characteristics: StudyCharacteristic[] = []
) => selectContentRecords(selectIntroductionRecords(records, protocol), protocol, characteristics).slice(0, MAX_TITLE_RECORDS);

export const getEvidenceSelection = (
  records: SLRRecord[],
  protocol: SLRProtocol,
  characteristics: StudyCharacteristic[] = []
) => {
  const introduction = selectIntroductionRecords(records, protocol);
  const content = selectContentRecords(introduction, protocol, characteristics);
  return { introduction, content, title: content.slice(0, MAX_TITLE_RECORDS), synthesis: content.slice(0, MAX_CONTENT_RECORDS), descriptive: content.slice(0, MAX_CONTENT_RECORDS), characteristics: content.slice(0, MAX_CONTENT_RECORDS) };
};
